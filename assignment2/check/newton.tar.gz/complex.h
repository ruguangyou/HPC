#ifndef COMPLEX_H_
#define COMPLEX_H_

void complex_d1 (double *cpx);
void complex_d2 (double *cpx);
void complex_d3 (double *cpx);
void complex_d4 (double *cpx);
void complex_d5 (double *cpx);
void complex_d6 (double *cpx);
void complex_d7 (double *cpx);
void complex_d8 (double *cpx);
void complex_d9 (double *cpx);

#endif
