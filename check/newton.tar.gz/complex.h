#ifndef COMPLEX_H_
#define COMPLEX_H_

void complex_power_0 (double *cpx);
void complex_power_1 (double *cpx);
void complex_power_2 (double *cpx);
void complex_power_3 (double *cpx);
void complex_power_4 (double *cpx);
void complex_power_5 (double *cpx);
void complex_power_6 (double *cpx);
void complex_power_7 (double *cpx);
void complex_power_8 (double *cpx);
void complex_power_9 (double *cpx);

#endif
