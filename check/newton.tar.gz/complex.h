#ifndef COMPLEX_H_
#define COMPLEX_H_

void complex_power_d1 (double *cpx);
void complex_power_d2 (double *cpx);
void complex_power_d3 (double *cpx);
void complex_power_d4 (double *cpx);
void complex_power_d5 (double *cpx);
void complex_power_d6 (double *cpx);
void complex_power_d7 (double *cpx);
void complex_power_d8 (double *cpx);
void complex_power_d9 (double *cpx);

#endif
