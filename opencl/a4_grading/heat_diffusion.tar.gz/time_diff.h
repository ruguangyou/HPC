#ifndef TIME_DIFF_H
#define TIME_DIFF_H

#include <time.h>
void time_diff(struct timespec *start, struct timespec *stop, struct timespec *result);

#endif
